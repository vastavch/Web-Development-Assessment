describe("addColor",function(){
                               var addCol;
                               beforeEach(function() {
                                                        addCol = new AddColor();
                                                        addCol.colors=[];
                                                        addCol.colors.push(new Color("Black", 0, 0, -100));
                                                        addCol.colors.push(new Color("Brown", 1, 1, 1));
                                                        addCol.colors.push(new Color("Red", 2, 2, 2));
                                                        addCol.colors.push(new Color("Orange", 3, 3, -100));
                                                        addCol.colors.push(new Color("Yellow", 4, 4, 5));
                                                        addCol.colors.push(new Color("Green", 5, 5, 0.5));
                                                        addCol.colors.push(new Color("Blue", 6, 6, 0.25));
                                                        addCol.colors.push(new Color("Violet", 7, 7, 0.1));
                                                        addCol.colors.push(new Color("Gray", 8, 8, 0.05));
                                                        addCol.colors.push(new Color("White", 9, 9, -100));
                                                        addCol.colors.push(new Color("Gold", -100, -1, 5));
                                                        addCol.colors.push(new Color("Silver", -100, -2, 10));
                                                        addCol.colors.push(new Color("None", -100, -100, 20));

                                });
                               //tests "getColor()" functionality
                                describe("getColor", function() {
                                
                                                                it("getColor returns -100 for not defined color", function() {

                                                                       expect(addCol.getColor("Hui")).toEqual(-100);
                                                                   });
                                                                it("getColor returns correct color object ", function() {
                                                                         //loadOptions();
                                                                         var color=addCol.getColor("Black");
                                                                         expect(color.name).toEqual("Black");
                                                                   });
                                });
                                //tests "calculateOhmValue()" functionality
                                describe("calculateOhmValue",function(){
                                                                //tests the case when unaccpeted colors are passed;
                                                                describe("resistance cannot be calculated",function(){
                                                                   it("Unaccepted color as first argument",function(){
                                                                        var res=addCol.CalculateOhmValue("None","Black","Black","red");
                                                                        expect(res).toEqual("Resistance cannot be calculated for given Combination");
                                                                      });
                                                                    it("Unaccepted color as second argument",function(){
                                                                        var res=addCol.CalculateOhmValue("Black","None","Black","red");
                                                                        expect(res).toEqual("Resistance cannot be calculated for given Combination");
                                                                      });
                                                                    it("Unaccepted color as third argument",function(){
                                                                        var res=addCol.CalculateOhmValue("Black","Black","None","red");
                                                                        expect(res).toEqual("Resistance cannot be calculated for given Combination");
                                                                      });
                                                                });
                                                                //tests the case of zero tolerance or unspecified tolerance   
                                                                it("resistance for zero tolerance resitance",function(){
                                                                   var res=addCol.CalculateOhmValue("Black","Black","Black","Black");
                                                                   expect(res).toEqual("Resistance is 0ohms");
                                                                });
                                                                //tests the case of non zero tolerance
                                                                it("resistance for non zero tolerance resitance",function(){
                                                                   var res=addCol.CalculateOhmValue("Yellow","Violet","Red","Gold");
                                                                   expect(res).toEqual("Resistance is in between 4465ohms and 4935ohms");
                                                                });
                                });
                                //tests loadOptions functionality
                                describe("loadOptions",function(){
                                    
                                                           it("options Correctly loaded",function(){
                                                                 var opt="<option>Black</option>"+
                                                                         "<option>Brown</option>"+
                                                                         "<option>Red</option>"+
                                                                         "<option>Orange</option>"+
                                                                         "<option>Yellow</option>"+
                                                                         "<option>Green</option>"+
                                                                         "<option>Blue</option>"+
                                                                         "<option>Violet</option>"+
                                                                         "<option>Gray</option>"+
                                                                         "<option>White</option>"+
                                                                         "<option>Gold</option>"+
                                                                         "<option>Silver</option>"+
                                                                         "<option>None</option>"+

                                                                  expect(loadOptions()).toEqual(opt);
                                                            });
                                }); 
                                
});