/**
* commented code in this file is actual part of developed javascript.
* This code is commented because it accesses the HTML elements and some values are returned instead of assigning them to HTML elements, to evaluate the functions.
 *  
 * 
 */
function AddColor() {
}
var addColor;
AddColor.prototype.addColors = function() {
	this.colors = [];
	this.colors.push(new Color("Black", 0, 0, -100));
	this.colors.push(new Color("Brown", 1, 1, 1));
	this.colors.push(new Color("Red", 2, 2, 2));
	this.colors.push(new Color("Orange", 3, 3, -100));
	this.colors.push(new Color("Yellow", 4, 4, 5));
	this.colors.push(new Color("Green", 5, 5, 0.5));
	this.colors.push(new Color("Blue", 6, 6, 0.25));
	this.colors.push(new Color("Violet", 7, 7, 0.1));
	this.colors.push(new Color("Gray", 8, 8, 0.05));
	this.colors.push(new Color("White", 9, 9, -100));
	this.colors.push(new Color("Gold", -100, -1, 5));
	this.colors.push(new Color("Silver", -100, -2, 10));
	this.colors.push(new Color("None", -100, -100, 20));
}
AddColor.prototype.getColor = function(col) {
	
    var colors_len = this.colors.length;
	for (var i = 0; i < colors_len; i++) {
		if (col == this.colors[i].name) {
			return this.colors[i];
		}
	}
	return -100;
    
}
AddColor.prototype.CalculateOhmValue = function(bandAColor, bandBColor,
		bandCColor, bandDColor) {
    
    var sfigure2 = this.getColor(bandBColor).sfigure;
	var multiplier = this.getColor(bandCColor).multiplier;
	var tolerance = this.getColor(bandDColor).tolerance;
    var sfigure1 = this.getColor(bandAColor).sfigure;
	if (sfigure1 == -100 || sfigure2 == -100 || multiplier == -100) {
		//document.getElementById("result").innerHTML = "Resistance cannot be calculated for given Combination";
		return "Resistance cannot be calculated for given Combination";
	} else {

		var resistance = (sfigure1 * 10) + sfigure2;
		resistance = resistance * Math.pow(10, multiplier);
		if (tolerance == 0 || tolerance==-100) {
			/*document.getElementById("result").innerHTML = "Resistance is "
					+ resistance + "ohms";*/
            return "Resistance is "+ resistance + "ohms";
		} else {
			var min_res = resistance - ((resistance * 0.01) * tolerance);
			var max_res = resistance + (resistance * 0.01 * tolerance);
			/*document.getElementById("result").innerHTML = "Resistance is in between "
					+ min_res + "ohms and " + max_res+"ohms";*/
            return "Resistance is in between "+ min_res + "ohms and " + max_res+"ohms";
		}
	}
}

function loadOptions() {

	addColor = new AddColor();
	addColor.addColors();
	addColor.len_colors = addColor.colors.length;
	addColor.options = "";
	for (var i = 0; i < addColor.len_colors; i++) {
		addColor.options += "<option>" + addColor.colors[i].name + "</option>";
	}
/*	document.getElementById("menu").innerHTML = addColor.options;
	document.getElementById("menu2").innerHTML = addColor.options;
	document.getElementById("menu3").innerHTML = addColor.options;
	document.getElementById("menu4").innerHTML = addColor.options;*/
    //return addColor.options;
    
}
function getData() {
	addColor.CalculateOhmValue(document.getElementById("menu").value, document
			.getElementById("menu2").value,
			document.getElementById("menu3").value, document
					.getElementById("menu4").value);
    

}