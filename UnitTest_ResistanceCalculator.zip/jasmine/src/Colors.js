/**
 * 
 */
var Color=function(name,sfigure,multiplier,tolerance){
      this.name=name;
      this.sfigure=sfigure;
      this.multiplier=multiplier;
      this.tolerance=tolerance;
}
 



